<!DOCTYPE html>
<html>
    <head>
        <title>FormulaireAdaptatif</title>
    </head>
    <body>
        <form action="formulaireGenerer.php" method="post">

            <label for="name">Combien de personnes voulez-vous saisir : </label>
            <input type="text" name="nombre" id="nombre" required />

            <input type="submit" value="Submit" />

        </form>
    </body>
</html>


