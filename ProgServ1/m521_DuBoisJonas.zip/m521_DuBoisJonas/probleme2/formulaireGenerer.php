<?php
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <title>FormulaireAdaptatif</title>
    </head>
    <body>
        <form action="AffichePrenom.php" method="post">
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                if (isset($_POST['nombre'])) {
                    if (filter_input(INPUT_POST, 'nombre')) {
                        $nombre = $_POST['nombre'];
                        if (ctype_digit($nombre)) {
                            $_SESSION['nombre'] = $nombre;
                            for ($i = 1; $i <= $nombre; $i++) {
                                echo "<h3>Personne $i</h3><br>";
                                echo "<label for = 'name'>nom : </label>";
                                echo "<input type = 'text' name = 'name[]' id = 'name' required />";
                                echo "<label for = 'forname'>Prénom : </label>";
                                echo "<input type = 'text' name = 'forname[]' id = 'forname' required />";
                            }
                        }
                    }
                }
            }
            ?>

            <input type="submit" value="Submit" />

        </form>
    </body>
</html>



