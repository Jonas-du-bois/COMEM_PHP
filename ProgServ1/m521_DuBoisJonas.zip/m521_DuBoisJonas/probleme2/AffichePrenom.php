<?php

session_start();
$nombre = $_SESSION['nombre'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Vérifie si un nombre a été sélectionné
    if (isset($_POST['name']) && isset($_POST['forname'])) {
        $name = $_POST['name'];
        $forname = $_POST['forname'];
        echo "<h2>Vous avez choisi les $nombre personnes suivante : </h2>";
        // Affichage des données dans le tableau

        for ($index = 0; $index < count($name); $index++) {
            echo "- $name[$index]";
            echo " ";
            echo " $forname[$index]";
            echo "<br>";
        }
    } else {
        echo "<p>Vous n'avez choisi personne</p>";
    }
}
